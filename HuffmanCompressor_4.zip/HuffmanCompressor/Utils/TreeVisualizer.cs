using HuffmanCompressor.Models;

namespace HuffmanCompressor.Utils;

/// <summary>
/// Muestra una representación visual indentada del árbol de Huffman en consola.
/// Izquierda = bit 0, Derecha = bit 1.
/// </summary>
public static class TreeVisualizer
{
    /// <summary>
    /// Imprime el árbol de Huffman con conectores de línea.
    /// Ejemplo de salida:
    ///   [Raíz: 100]
    ///   ├── (0) 'a' (freq: 60)
    ///   └── (1) [Interno: 40]
    ///       ├── (0) 'b' (freq: 20)
    ///       └── (1) 'c' (freq: 20)
    /// </summary>
    public static void Display(HuffmanNode root)
    {
        Console.WriteLine();
        Console.WriteLine("  Árbol de Huffman:");
        Console.WriteLine();

        string rootLabel = root.IsLeaf
            ? $"  [Raíz/Hoja: {FormatChar(root.Character!.Value)} freq: {root.Frequency}]"
            : $"  [Raíz: {root.Frequency}]";

        Console.WriteLine(rootLabel);
        PrintNode(root.Left, "  ", isLeft: true, "0");
        PrintNode(root.Right, "  ", isLeft: false, "1");

        Console.WriteLine();
    }

    private static void PrintNode(HuffmanNode? node, string indent, bool isLeft, string bitLabel)
    {
        if (node is null) return;

        // Ignorar nodo ficticio '\0' del caso de un solo carácter
        if (node.IsLeaf && node.Character!.Value == '\0' && node.Frequency == 0)
            return;

        string connector = isLeft ? "├── " : "└── ";
        string childIndent = indent + (isLeft ? "│   " : "    ");

        if (node.IsLeaf)
        {
            string charDisplay = FormatChar(node.Character!.Value);
            Console.WriteLine($"{indent}{connector}({bitLabel}) {charDisplay} (freq: {node.Frequency})");
        }
        else
        {
            Console.WriteLine($"{indent}{connector}({bitLabel}) [Interno: {node.Frequency}]");
            PrintNode(node.Left, childIndent, isLeft: true, "0");
            PrintNode(node.Right, childIndent, isLeft: false, "1");
        }
    }

    private static string FormatChar(char c) => c switch
    {
        '\n' => "'\\n'",
        '\r' => "'\\r'",
        '\t' => "'\\t'",
        ' '  => "(espacio)",
        _    => $"'{c}'"
    };
}
