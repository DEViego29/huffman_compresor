namespace HuffmanCompressor.Utils;

/// <summary>
/// Calcula y muestra en consola las estadísticas de compresión.
/// </summary>
public static class StatsDisplay
{
    public static void ShowCompressionStats(long originalBytes, long compressedBytes, int uniqueChars, string originalPath, string compressedPath)
    {
        double ratio = originalBytes > 0
            ? (1.0 - (double)compressedBytes / originalBytes) * 100.0
            : 0.0;

        // Cabecera: 4 bytes (N) + uniqueChars * 6 bytes (char+freq) + 1 byte (padding)
        long headerSize = 4 + (long)uniqueChars * 6 + 1;
        long dataSize = compressedBytes - headerSize;

        Console.WriteLine();
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║            ESTADÍSTICAS DE COMPRESIÓN            ║");
        Console.WriteLine("╠══════════════════════════════════════════════════╣");
        Console.WriteLine($"║  Archivo original  : {Path.GetFileName(originalPath),-28}║");
        Console.WriteLine($"║  Archivo comprimido: {Path.GetFileName(compressedPath),-28}║");
        Console.WriteLine("╠══════════════════════════════════════════════════╣");
        Console.WriteLine($"║  Tamaño original   : {FormatBytes(originalBytes),-28}║");
        Console.WriteLine($"║  Tamaño comprimido : {FormatBytes(compressedBytes),-28}║");
        Console.WriteLine($"║    ├─ Cabecera     : {FormatBytes(headerSize),-28}║");
        Console.WriteLine($"║    └─ Datos        : {FormatBytes(dataSize),-28}║");
        Console.WriteLine($"║  Caracteres únicos : {uniqueChars,-28}║");
        Console.WriteLine($"║  Compresión lograda: {ratio:F2}%{new string(' ', 26 - $"{ratio:F2}%".Length)}║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝");

        if (ratio < 0)
        {
            Console.WriteLine();
            Console.WriteLine("  Nota: El archivo comprimido es más grande que el original.");
            Console.WriteLine("  Esto es normal en archivos pequeños: la cabecera que almacena");
            Console.WriteLine($"  la tabla de frecuencias ({FormatBytes(headerSize)}) supera el ahorro");
            Console.WriteLine("  obtenido por la codificación. Huffman es más efectivo en");
            Console.WriteLine("  archivos de mayor tamaño.");
        }

        Console.WriteLine();
    }

    public static void ShowDecompressionStats(long compressedBytes, long restoredBytes, string compressedPath, string restoredPath)
    {
        Console.WriteLine();
        Console.WriteLine("╔══════════════════════════════════════════╗");
        Console.WriteLine("║       ESTADÍSTICAS DE DESCOMPRESIÓN      ║");
        Console.WriteLine("╠══════════════════════════════════════════╣");
        Console.WriteLine($"║  Archivo comprimido : {Path.GetFileName(compressedPath),-20}║");
        Console.WriteLine($"║  Archivo restaurado : {Path.GetFileName(restoredPath),-20}║");
        Console.WriteLine("╠══════════════════════════════════════════╣");
        Console.WriteLine($"║  Tamaño comprimido  : {FormatBytes(compressedBytes),-20}║");
        Console.WriteLine($"║  Tamaño restaurado  : {FormatBytes(restoredBytes),-20}║");
        Console.WriteLine("╚══════════════════════════════════════════╝");
        Console.WriteLine();
    }

    private static string FormatBytes(long bytes)
    {
        if (bytes < 1024) return $"{bytes} bytes";
        if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F2} KB";
        return $"{bytes / (1024.0 * 1024):F2} MB";
    }
}
