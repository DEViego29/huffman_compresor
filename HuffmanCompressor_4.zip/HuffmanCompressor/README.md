# HuffmanCompressor

Compresión y descompresión de archivos de texto mediante el algoritmo de Huffman.

**Curso:** Análisis y Diseño de Algoritmos  
**Integrantes:**
- Chanin Fernando Huaman Farfan — 234893
- Diego Abraham Tunque Mamani — 234899
- Cristhofer Antony Mora Mamani — 241441

## ¿Qué hace?

Lee un archivo `.txt`, analiza la frecuencia de cada carácter, construye un árbol de Huffman y genera un archivo comprimido `.huff`. También realiza el proceso inverso: lee un `.huff` y reconstruye el `.txt` original, idéntico byte a byte.

## Requisitos

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)

## Cómo ejecutar

```bash
cd HuffmanCompressor
dotnet run
```

El programa muestra un menú interactivo con tres opciones:

1. **Comprimir** — Ingresa la ruta de un `.txt` y genera un `.huff`
2. **Descomprimir** — Ingresa la ruta de un `.huff` y restaura el `.txt`
3. **Salir**

## Estructura del proyecto

```
HuffmanCompressor/
├── Program.cs                  ← Menú y coordinación
├── Models/
│   └── HuffmanNode.cs          ← Nodo del árbol (hoja o interno)
├── Core/
│   ├── FrequencyAnalyzer.cs    ← Conteo de frecuencias O(n)
│   ├── HuffmanTree.cs          ← Construcción del árbol con min-heap
│   ├── CodeGenerator.cs        ← DFS para generar códigos binarios
│   ├── Compressor.cs           ← Texto → bits → bytes
│   └── Decompressor.cs         ← Bytes → bits → texto
├── IO/
│   ├── HuffFileWriter.cs       ← Escritura del .huff
│   └── HuffFileReader.cs       ← Lectura del .huff
└── Utils/
    ├── StatsDisplay.cs         ← Estadísticas de compresión
    └── TreeVisualizer.cs       ← Visualización del árbol en consola
```

## Dependencias externas

Ninguna. El proyecto usa exclusivamente la librería estándar de .NET 8. No hay paquetes NuGet.
