using HuffmanCompressor.Core;
using HuffmanCompressor.IO;
using HuffmanCompressor.Utils;

namespace HuffmanCompressor;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        ShowBanner();

        bool running = true;
        while (running)
        {
            ShowMenu();
            string? option = Console.ReadLine()?.Trim();

            switch (option)
            {
                case "1":
                    RunCompress();
                    break;
                case "2":
                    RunDecompress();
                    break;
                case "3":
                    running = false;
                    Console.WriteLine("\nSaliendo... ¡Hasta luego!\n");
                    break;
                default:
                    Console.WriteLine("\n  Opción no válida. Intente de nuevo.\n");
                    break;
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // COMPRESIÓN
    // ─────────────────────────────────────────────────────────────
    static void RunCompress()
    {
        Console.WriteLine("\n── COMPRIMIR ARCHIVO ──────────────────────────");

        string inputPath = AskPath("Ruta del archivo .txt a comprimir: ", mustExist: true);
        if (inputPath is null) return;

        string defaultOutput = Path.ChangeExtension(inputPath, ".huff");
        Console.Write($"Ruta de salida [{defaultOutput}]: ");
        string? outputInput = Console.ReadLine()?.Trim();
        string outputPath = string.IsNullOrEmpty(outputInput) ? defaultOutput : outputInput;

        try
        {
            Console.WriteLine("\n  Leyendo archivo...");
            string text = File.ReadAllText(inputPath, System.Text.Encoding.UTF8);

            if (text.Length == 0)
            {
                Console.WriteLine("  Error: el archivo está vacío.");
                return;
            }

            Console.WriteLine("  Analizando frecuencias...");
            var frequencies = FrequencyAnalyzer.Analyze(text);

            Console.WriteLine("  Construyendo árbol de Huffman...");
            var root = HuffmanTree.Build(frequencies);

            Console.WriteLine("  Generando códigos binarios...");
            var codes = CodeGenerator.Generate(root);

            Console.WriteLine("  Comprimiendo...");
            var (compressedBytes, padding) = Compressor.Compress(text, codes);

            Console.WriteLine("  Escribiendo archivo .huff...");
            HuffFileWriter.Write(outputPath, frequencies, compressedBytes, padding);

            long originalSize   = new FileInfo(inputPath).Length;
            long compressedSize = new FileInfo(outputPath).Length;

            Console.WriteLine("  ✓ Compresión completada.");
            StatsDisplay.ShowCompressionStats(originalSize, compressedSize, frequencies.Count, inputPath, outputPath);

            ShowCodeTable(codes, frequencies);

            Console.Write("  ¿Desea ver el árbol de Huffman? (s/n): ");
            if (Console.ReadLine()?.Trim().ToLower() == "s")
                TreeVisualizer.Display(root);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\n  Error durante la compresión: {ex.Message}");
        }
    }

    // ─────────────────────────────────────────────────────────────
    // DESCOMPRESIÓN
    // ─────────────────────────────────────────────────────────────
    static void RunDecompress()
    {
        Console.WriteLine("\n── DESCOMPRIMIR ARCHIVO ────────────────────────");

        string inputPath = AskPath("Ruta del archivo .huff a descomprimir: ", mustExist: true);
        if (inputPath is null) return;

        string defaultOutput = Path.ChangeExtension(inputPath, ".restored.txt");
        Console.Write($"Ruta de salida [{defaultOutput}]: ");
        string? outputInput = Console.ReadLine()?.Trim();
        string outputPath = string.IsNullOrEmpty(outputInput) ? defaultOutput : outputInput;

        try
        {
            Console.WriteLine("\n  Leyendo archivo .huff...");
            var (frequencies, padding, compressedBytes) = HuffFileReader.Read(inputPath);

            Console.WriteLine("  Reconstruyendo árbol de Huffman...");
            var root = HuffmanTree.Build(frequencies);

            Console.WriteLine("  Descomprimiendo...");
            string text = Decompressor.Decompress(compressedBytes, padding, root);

            Console.WriteLine("  Escribiendo archivo restaurado...");
            File.WriteAllText(outputPath, text, System.Text.Encoding.UTF8);

            long compressedSize = new FileInfo(inputPath).Length;
            long restoredSize   = new FileInfo(outputPath).Length;

            Console.WriteLine("  ✓ Descompresión completada.");
            StatsDisplay.ShowDecompressionStats(compressedSize, restoredSize, inputPath, outputPath);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\n  Error durante la descompresión: {ex.Message}");
        }
    }

    // ─────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────
    static string AskPath(string prompt, bool mustExist)
    {
        while (true)
        {
            Console.Write(prompt);
            string? path = Console.ReadLine()?.Trim().Trim('"');

            if (string.IsNullOrEmpty(path))
            {
                Console.WriteLine("  Operación cancelada.");
                return null!;
            }

            if (mustExist && !File.Exists(path))
            {
                Console.WriteLine($"  No se encontró el archivo: {path}");
                Console.Write("  ¿Intentar de nuevo? (s/n): ");
                if (Console.ReadLine()?.Trim().ToLower() != "s") return null!;
                continue;
            }

            return path;
        }
    }

    static void ShowCodeTable(Dictionary<char, string> codes, Dictionary<char, int> frequencies)
    {
        Console.WriteLine("  Tabla de códigos Huffman generada:");
        Console.WriteLine("  ┌──────────┬───────────┬──────────────────────┐");
        Console.WriteLine("  │ Carácter │ Frecuencia│ Código               │");
        Console.WriteLine("  ├──────────┼───────────┼──────────────────────┤");

        foreach (var (ch, code) in codes.OrderByDescending(x => frequencies[x.Key]))
        {
            string charDisplay = ch switch
            {
                '\n' => "\\n",
                '\r' => "\\r",
                '\t' => "\\t",
                ' '  => "(sp)",
                _    => ch.ToString()
            };
            Console.WriteLine($"  │ {charDisplay,-8} │ {frequencies[ch],-9} │ {code,-20} │");
        }

        Console.WriteLine("  └──────────┴───────────┴──────────────────────┘");
        Console.WriteLine();
    }

    static void ShowBanner()
    {
        Console.WriteLine();
        Console.WriteLine("  ██╗  ██╗██╗   ██╗███████╗███████╗███╗   ███╗ █████╗ ███╗   ██╗");
        Console.WriteLine("  ██║  ██║██║   ██║██╔════╝██╔════╝████╗ ████║██╔══██╗████╗  ██║");
        Console.WriteLine("  ███████║██║   ██║█████╗  █████╗  ██╔████╔██║███████║██╔██╗ ██║");
        Console.WriteLine("  ██╔══██║██║   ██║██╔══╝  ██╔══╝  ██║╚██╔╝██║██╔══██║██║╚██╗██║");
        Console.WriteLine("  ██║  ██║╚██████╔╝██║     ██║     ██║ ╚═╝ ██║██║  ██║██║ ╚████║");
        Console.WriteLine("  ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝     ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝");
        Console.WriteLine();
        Console.WriteLine("         Compresión de archivos — Algoritmo de Huffman");
        Console.WriteLine("         Análisis y Diseño de Algoritmos — 2026");
        Console.WriteLine();
    }

    static void ShowMenu()
    {
        Console.WriteLine("  ┌────────────────────────────────────┐");
        Console.WriteLine("  │            MENÚ PRINCIPAL          │");
        Console.WriteLine("  ├────────────────────────────────────┤");
        Console.WriteLine("  │  1. Comprimir archivo (.txt)       │");
        Console.WriteLine("  │  2. Descomprimir archivo (.huff)   │");
        Console.WriteLine("  │  3. Salir                          │");
        Console.WriteLine("  └────────────────────────────────────┘");
        Console.Write("  Seleccione una opción: ");
    }
}
