namespace HuffmanCompressor.IO;

/// <summary>
/// Escribe un archivo .huff al disco con el siguiente formato:
///
///   CABECERA:
///     [4 bytes] int   — número de entradas en la tabla de frecuencias (N)
///     por cada entrada:
///       [2 bytes] char — carácter (UTF-16)
///       [4 bytes] int  — frecuencia
///
///   METADATOS:
///     [1 byte] byte — bits de padding al final del bloque de datos
///
///   DATOS:
///     [N bytes] — bits comprimidos empaquetados en bytes
/// </summary>
public static class HuffFileWriter
{
    public static void Write(
        string outputPath,
        Dictionary<char, int> frequencies,
        byte[] compressedBytes,
        byte padding)
    {
        using var writer = new BinaryWriter(File.Open(outputPath, FileMode.Create));

        // --- CABECERA: tabla de frecuencias ---
        writer.Write(frequencies.Count); // número de entradas

        foreach (var (character, frequency) in frequencies)
        {
            writer.Write(character);  // 2 bytes (UTF-16)
            writer.Write(frequency);  // 4 bytes
        }

        // --- METADATOS: padding ---
        writer.Write(padding); // 1 byte

        // --- DATOS: bits comprimidos ---
        writer.Write(compressedBytes);
    }
}
