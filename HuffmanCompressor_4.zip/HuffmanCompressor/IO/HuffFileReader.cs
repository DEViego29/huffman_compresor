namespace HuffmanCompressor.IO;

/// <summary>
/// Lee y deserializa un archivo .huff del disco.
/// Devuelve la tabla de frecuencias, el padding y los bytes comprimidos.
/// </summary>
public static class HuffFileReader
{
    public static (Dictionary<char, int> Frequencies, byte Padding, byte[] CompressedBytes) Read(string inputPath)
    {
        if (!File.Exists(inputPath))
            throw new FileNotFoundException($"No se encontró el archivo: {inputPath}");

        using var reader = new BinaryReader(File.Open(inputPath, FileMode.Open));

        // --- CABECERA: tabla de frecuencias ---
        int entryCount = reader.ReadInt32();
        var frequencies = new Dictionary<char, int>(entryCount);

        for (int i = 0; i < entryCount; i++)
        {
            char character = reader.ReadChar();
            int frequency  = reader.ReadInt32();
            frequencies[character] = frequency;
        }

        // --- METADATOS: padding ---
        byte padding = reader.ReadByte();

        // --- DATOS: resto del archivo = bytes comprimidos ---
        byte[] compressedBytes = reader.ReadBytes((int)(reader.BaseStream.Length - reader.BaseStream.Position));

        return (frequencies, padding, compressedBytes);
    }
}
