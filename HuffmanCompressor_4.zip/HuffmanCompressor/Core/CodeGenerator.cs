using HuffmanCompressor.Models;

namespace HuffmanCompressor.Core;

/// <summary>
/// Recorre el árbol de Huffman en profundidad (DFS) y genera
/// la tabla de códigos binarios para cada carácter.
/// Izquierda = "0", Derecha = "1".
/// </summary>
public static class CodeGenerator
{
    /// <summary>
    /// Devuelve { carácter → código binario como string }.
    /// Ejemplo: { 'a' → "101", 'e' → "01", ' ' → "00" }
    /// </summary>
    public static Dictionary<char, string> Generate(HuffmanNode root)
    {
        ArgumentNullException.ThrowIfNull(root);

        var codes = new Dictionary<char, string>();
        Traverse(root, string.Empty, codes);
        return codes;
    }

    private static void Traverse(HuffmanNode node, string currentCode, Dictionary<char, string> codes)
    {
        if (node.IsLeaf)
        {
            // Ignorar el nodo ficticio '\0' creado para el caso de un solo carácter
            if (node.Character!.Value == '\0' && node.Frequency == 0)
                return;

            // Nodo hoja: asignamos el código acumulado.
            // Si el árbol tiene un solo nodo (caso especial), asignamos "0".
            codes[node.Character!.Value] = currentCode.Length == 0 ? "0" : currentCode;
            return;
        }

        if (node.Left is not null)
            Traverse(node.Left, currentCode + "0", codes);

        if (node.Right is not null)
            Traverse(node.Right, currentCode + "1", codes);
    }
}
