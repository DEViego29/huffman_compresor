using HuffmanCompressor.Models;

namespace HuffmanCompressor.Core;

/// <summary>
/// Reconstruye el texto original a partir de los bytes comprimidos
/// navegando el árbol de Huffman bit a bit.
/// </summary>
public static class Decompressor
{
    /// <summary>
    /// Descomprime los bytes usando el árbol de Huffman y el padding conocido.
    /// Complejidad: O(n * h) donde n = bits totales, h = altura del árbol.
    /// En la práctica O(n) porque h está acotado por log(alfabeto).
    /// </summary>
    public static string Decompress(byte[] compressedBytes, byte padding, HuffmanNode root)
    {
        ArgumentNullException.ThrowIfNull(compressedBytes);
        ArgumentNullException.ThrowIfNull(root);

        var result = new System.Text.StringBuilder();
        HuffmanNode current = root;

        int totalBits = compressedBytes.Length * 8 - padding;

        for (int i = 0; i < totalBits; i++)
        {
            // Extraer el bit i: byte i/8, posición 7-(i%8) (MSB primero)
            int byteIndex = i / 8;
            int bitPosition = 7 - (i % 8);
            bool bit = (compressedBytes[byteIndex] & (1 << bitPosition)) != 0;

            // Navegar el árbol: 0 = izquierda, 1 = derecha
            current = bit ? current.Right! : current.Left!;

            if (current.IsLeaf)
            {
                result.Append(current.Character!.Value);
                current = root; // volver a la raíz para el siguiente carácter
            }
        }

        return result.ToString();
    }
}
