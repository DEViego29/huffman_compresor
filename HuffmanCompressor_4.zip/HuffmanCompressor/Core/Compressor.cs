namespace HuffmanCompressor.Core;

/// <summary>
/// Convierte un texto a su representación comprimida en bytes
/// usando la tabla de códigos de Huffman.
/// </summary>
public static class Compressor
{
    /// <summary>
    /// Comprime el texto y devuelve los bytes comprimidos y el padding aplicado.
    /// El padding indica cuántos bits del último byte son relleno (no datos reales).
    /// </summary>
    public static (byte[] CompressedBytes, byte Padding) Compress(
        string text,
        Dictionary<char, string> codes)
    {
        // Paso 1: construir el stream completo de bits como string
        var bitStream = new System.Text.StringBuilder();
        foreach (char c in text)
        {
            if (!codes.TryGetValue(c, out string? code))
                throw new InvalidOperationException($"Carácter '{c}' no tiene código asignado.");
            bitStream.Append(code);
        }

        string bits = bitStream.ToString();
        int totalBits = bits.Length;

        // Paso 2: calcular padding necesario para completar el último byte
        byte padding = (byte)((8 - totalBits % 8) % 8);

        // Paso 3: empaquetar bits en bytes
        int totalBytes = (totalBits + padding) / 8;
        byte[] compressedBytes = new byte[totalBytes];

        for (int i = 0; i < totalBits; i++)
        {
            if (bits[i] == '1')
            {
                // Bit i va en el byte i/8, en la posición 7-(i%8) (MSB primero)
                compressedBytes[i / 8] |= (byte)(1 << (7 - (i % 8)));
            }
        }
        // Los bits de padding ya son 0 por defecto en el array

        return (compressedBytes, padding);
    }
}
