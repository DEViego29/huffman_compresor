using HuffmanCompressor.Models;

namespace HuffmanCompressor.Core;

/// <summary>
/// Construye el árbol de Huffman a partir de una tabla de frecuencias.
/// Usa un min-heap (PriorityQueue) para extraer siempre los dos nodos
/// de menor frecuencia: estrategia voraz clásica de Huffman.
/// </summary>
public static class HuffmanTree
{
    /// <summary>
    /// Construye y devuelve la raíz del árbol de Huffman.
    /// Complejidad: O(n log n) donde n = número de caracteres distintos.
    /// </summary>
    public static HuffmanNode Build(Dictionary<char, int> frequencies)
    {
        if (frequencies is null || frequencies.Count == 0)
            throw new ArgumentException("La tabla de frecuencias no puede estar vacía.", nameof(frequencies));

        // Min-heap: prioridad = frecuencia (menor frecuencia = mayor prioridad)
        var heap = new PriorityQueue<HuffmanNode, int>();

        foreach (var (character, frequency) in frequencies)
            heap.Enqueue(new HuffmanNode(character, frequency), frequency);

        // Caso especial: un solo carácter distinto
        // Necesitamos al menos 2 nodos para tener un árbol con ramas.
        if (heap.Count == 1)
        {
            var single = heap.Dequeue();
            // Creamos un nodo interno ficticio para que el nodo hoja tenga código "0"
            return new HuffmanNode(single, new HuffmanNode('\0', 0));
        }

        // Algoritmo voraz: mientras haya más de un nodo en el heap,
        // extraer los dos de menor frecuencia y combinarlos.
        while (heap.Count > 1)
        {
            var left  = heap.Dequeue();
            var right = heap.Dequeue();
            var parent = new HuffmanNode(left, right);
            heap.Enqueue(parent, parent.Frequency);
        }

        return heap.Dequeue(); // raíz del árbol completo
    }
}
