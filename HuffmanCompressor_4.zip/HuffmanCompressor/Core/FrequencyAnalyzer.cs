namespace HuffmanCompressor.Core;

/// <summary>
/// Analiza un texto y devuelve la frecuencia de aparición de cada carácter.
/// </summary>
public static class FrequencyAnalyzer
{
    /// <summary>
    /// Recorre el texto una sola vez: O(n).
    /// Devuelve un diccionario { carácter → cantidad de apariciones }.
    /// </summary>
    public static Dictionary<char, int> Analyze(string text)
    {
        if (string.IsNullOrEmpty(text))
            throw new ArgumentException("El texto no puede estar vacío.", nameof(text));

        var frequencies = new Dictionary<char, int>();

        foreach (char c in text)
        {
            if (frequencies.TryGetValue(c, out int count))
                frequencies[c] = count + 1;
            else
                frequencies[c] = 1;
        }

        return frequencies;
    }
}
