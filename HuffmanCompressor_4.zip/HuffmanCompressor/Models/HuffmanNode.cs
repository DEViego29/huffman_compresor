namespace HuffmanCompressor.Models;

/// <summary>
/// Nodo del árbol de Huffman.
/// Los nodos hoja almacenan un carácter; los nodos internos tienen Character = null.
/// </summary>
public class HuffmanNode
{
    public char? Character { get; }
    public int Frequency { get; }
    public HuffmanNode? Left { get; }
    public HuffmanNode? Right { get; }

    public bool IsLeaf => Left is null && Right is null;

    // Constructor para nodo hoja
    public HuffmanNode(char character, int frequency)
    {
        Character = character;
        Frequency = frequency;
    }

    // Constructor para nodo interno
    public HuffmanNode(HuffmanNode left, HuffmanNode right)
    {
        Character = null;
        Frequency = left.Frequency + right.Frequency;
        Left = left;
        Right = right;
    }
}
